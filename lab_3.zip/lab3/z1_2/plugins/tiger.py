class tiger:
    def __init__(self, name) -> None:
        self.name = name

    def getName(self):
        return self.name
    
    def greet(self):
        return "roarr"
    
    def menu(self):
        return "fino meso"