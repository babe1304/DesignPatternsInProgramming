class parrot:
    def __init__(self, name) -> None:
        self.name = name

    def getName(self):
        return self.name
    
    def greet(self):
        return "kha kha"
    
    def menu(self):
        return "orašaste plodove"