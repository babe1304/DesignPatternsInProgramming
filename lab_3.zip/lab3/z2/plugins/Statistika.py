class Statistika:
    def __init__(self) -> None:
        pass
    def getName(self):
        return "Statistika"
    
    def getDescription(self):
        return "Plugin koji broji koliko ima redaka, riječi i slova u dokumentu i to prikazuje korisniku u dijalogu."
    
    def execute(self, model, undoManager=None, clipboardStack=None):
        stats = {"lines":0, "words":0, "chars":0}
        for line in model.lines:
            stats["lines"] += 1
            words = line.split(" ")
            for word in words:
                stats["words"] += 1
                for letter in word:
                    stats["chars"] += 1
        return stats